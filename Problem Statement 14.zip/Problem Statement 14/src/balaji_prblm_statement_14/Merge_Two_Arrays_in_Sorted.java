package balaji_prblm_statement_14;

import java.util.Arrays;

class Merge_Two_Arrays_in_Sorted{
	public static void sortedMerge(int a[], int b[],int res[], int n,int m)
	{
		// Concatenate two arrays
		int i = 0, j = 0, k = 0;
		while (i < n) {
			res[k] = a[i];
			i++;
			k++;
		}
		while (j < m) {
			res[k] = b[j];
			j++;
			k++;
		}
		// sorting the res array
		Arrays.sort(res);
	}
	/* Driver program to test above function */
	public static void main(String[] args)
	{
		int a[] = { 11, 9, 18 };
		int b[] = { 21, 3, 2, 12 };
		int n = a.length;
		int m = b.length;
	
		// Final merge list
		int res[]=new int[n + m];
		sortedMerge(a, b, res, n, m);
	
		System.out.print("Sorted merged list :");
		for (int i = 0; i < n + m; i++)
			System.out.print(" " + res[i]);
	}
}



