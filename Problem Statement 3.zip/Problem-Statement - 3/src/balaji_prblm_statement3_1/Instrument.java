package balaji_prblm_statement3_1;

public abstract class Instrument {
	public abstract void play();
}

