package balaji_prblm_statement7_2;

public class NameException extends Exception
{
    public String validname()
    {
         return ("Name is not Valid..Please ReEnter the Name");
    }
}