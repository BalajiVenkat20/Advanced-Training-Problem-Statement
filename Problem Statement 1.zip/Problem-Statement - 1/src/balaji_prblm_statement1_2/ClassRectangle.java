package balaji_prblm_statement1_2;

import java.util.Scanner;

public class ClassRectangle {
	
	int length; 
    int breadth; 
    int area; 
   
    public ClassRectangle()
    {
    	length = 0;
    	breadth= 0;
    }

    void input() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = in.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        breadth = in.nextInt();
    }

    void calculate() {
        area = length * breadth;
        
    }

    void display() {
        System.out.println("Area of Rectangle = " + area);
       
    }

    public static void main(String args[]) {
        ClassRectangle obj1 = new ClassRectangle();
        obj1.input();
        obj1.calculate();
        obj1.display();
        System.out.println("________________________________");
        ClassRectangle obj2 = new ClassRectangle();
        obj2.input();
        obj2.calculate();
        obj2.display();
        System.out.println("________________________________");
        ClassRectangle obj3 = new ClassRectangle();
        obj3.input();
        obj3.calculate();
        obj3.display();
        System.out.println("________________________________");
        ClassRectangle obj4 = new ClassRectangle();
        obj4.input();
        obj4.calculate();
        obj4.display();
        System.out.println("________________________________");
        ClassRectangle obj5 = new ClassRectangle();
        obj5.input();
        obj5.calculate();
        obj5.display();
    }
}
